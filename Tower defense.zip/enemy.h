#ifndef ENEMY_H
#define ENEMY_H

#include<QGraphicsPixmapItem>
#include<QGraphicsItem>
#include<QObject>
#include<QMediaPlayer>
#include<QProgressBar>

class Enemy: public QObject, public QGraphicsPixmapItem
{
    Q_OBJECT
public:
    explicit Enemy(int waveIndex, QObject *parent = nullptr);
    ~Enemy();

public slots:
    void move();
    void takeDamage(int damage);

signals:
    void enemyDestroyed(Enemy* enemy);

private:
    int health;
    int maxHealth;
    bool isAlive;
    QMediaPlayer* lose;
    QMediaPlayer* sound;
    QAudioOutput* mainlosing;
    QProgressBar healthBar;
};

#endif // ENEMY_H
