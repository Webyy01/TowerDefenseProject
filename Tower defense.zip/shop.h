#ifndef SHOP_H
#define SHOP_H

class Shop
{
public:
    Shop();
};

#endif // SHOP_H
