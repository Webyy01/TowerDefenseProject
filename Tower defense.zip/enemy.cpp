// enemy.cpp
#include "Enemy.h"
#include "QTimer"
#include "QAudioOutput"
#include "QGraphicsScene"
#include "QGraphicsProxyWidget"
#include "Bullet.h"

Enemy::Enemy(int waveIndex, QObject *parent) : QObject(), QGraphicsPixmapItem(), lose(new QMediaPlayer()), sound(new QMediaPlayer()), mainlosing(new QAudioOutput()){
    (void)waveIndex; // Suppress unused parameter warning
    (void)parent;    // Suppress unused parameter warning

    health = 100;
    isAlive = true;

    setPixmap(QPixmap(":/images/enemy.png").scaled(70, 70));

    QTimer *timer = new QTimer();
    connect(timer, SIGNAL(timeout()), this, SLOT(move()));
    timer->start(50);

    mainlosing->setVolume(10);
    lose->setAudioOutput(mainlosing);
    lose->setSource(QUrl(":/audios/balloonpop.mp3"));

    QProgressBar healthBar;
    healthBar.setMinimum(0);
    healthBar.setMaximum(100);
    healthBar.setValue(health);

    QGraphicsProxyWidget *proxy = new QGraphicsProxyWidget(this);
    proxy->setWidget(&healthBar);
    proxy->setPos(0, -10);
    proxy->setParentItem(this);
}

Enemy::~Enemy() {
    delete lose;
    delete sound;
    delete mainlosing;
}

void Enemy::move() {
    QList<QGraphicsItem *> collideItems = collidingItems();
    for (int i = 0; i < collideItems.size(); ++i) {
        if (typeid(*(collideItems[i])) == typeid(Bullet)) {
            Bullet *bullet = dynamic_cast<Bullet*>(collideItems[i]);
            if (bullet) {
                sound->play();
                scene()->removeItem(bullet);
                takeDamage(bullet->getDamage());
                delete bullet;
                return;
            }
        }
    }
}

void Enemy::takeDamage(int damage) {
    health -= damage;
    if (health <= 0) {
        isAlive = false;
        lose->play();
        emit enemyDestroyed(this);
    }
}
