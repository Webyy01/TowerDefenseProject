#ifndef CANNONTOWER_H
#define CANNONTOWER_H

#include "tower.h"
#include <QObject>
#include <QGraphicsPixmapItem>
#include <QString>
#include <vector>

class CannonTower : public Tower {
public:
    CannonTower();
    void shoot() override;
    bool upgrade(int& playerCurrency) override;
    void setLevelImage() override;

private:
    static const std::vector<QString> levelImages;
};

#endif // CANNONTOWER_H
