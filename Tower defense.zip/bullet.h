#ifndef BULLET_H
#define BULLET_H

#include <QGraphicsPixmapItem>

class Bullet : public QGraphicsPixmapItem {
public:
    Bullet();

    void setDamage(int damage);
    int getDamage() const;

private:
    int damage;
};

#endif // BULLET_H
